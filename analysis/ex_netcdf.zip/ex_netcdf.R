library(RNetCDF)

nc <- RNetCDF::open.nc(con = "test_gapctd.nc")

RNetCDF::print.nc(nc)

RNetCDF::dim.inq.nc(nc, dimension = "depth")
RNetCDF::dim.inq.nc(nc, dimension = "index")

RNetCDF::var.get.nc(nc, variable = "latitude")
RNetCDF::var.get.nc(nc, variable = "longitude")
RNetCDF::var.get.nc(nc, variable = "time")
RNetCDF::var.get.nc(nc, variable = "sea_water_temperature")
RNetCDF::att.get.nc(nc, variable = "sea_water_temperature", attribute = "units")

RNetCDF::var.get.nc(nc, variable = "sea_water_practical_salinity")
RNetCDF::att.get.nc(nc, variable = "sea_water_practical_salinity", attribute = "units")

RNetCDF::var.get.nc(nc, variable = "sea_water_salinity")
RNetCDF::att.get.nc(nc, variable = "sea_water_salinity", attribute = "units")

RNetCDF::var.get.nc(nc, variable = "sea_floor_temperature")
RNetCDF::att.get.nc(nc, variable = "sea_floor_temperature", attribute = "units")

RNetCDF::var.get.nc(nc, variable = "sea_floor_sound_speed_in_sea_water")
RNetCDF::att.get.nc(nc, variable = "sea_floor_sound_speed_in_sea_water", attribute = "units")

RNetCDF::att.get.nc(nc, variable = "NC_GLOBAL", attribute = "cruise")
RNetCDF::att.get.nc(nc, variable = "NC_GLOBAL", attribute = "time_coverage_start")

RNetCDF::att.get.nc(nc, variable = "instrument", attribute = "calibration_date")
RNetCDF::att.get.nc(nc, variable = "instrument", attribute = "make_model")