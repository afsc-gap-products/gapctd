library(RNetCDF)


# Viewing data with RNetCDF package
nc <- RNetCDF::open.nc(con = "test_gapctd.nc")

RNetCDF::print.nc(nc)

RNetCDF::dim.inq.nc(nc, dimension = "depth")
RNetCDF::dim.inq.nc(nc, dimension = "index")

RNetCDF::var.get.nc(nc, variable = "latitude")
RNetCDF::var.get.nc(nc, variable = "longitude")
RNetCDF::var.get.nc(nc, variable = "time")
RNetCDF::var.get.nc(nc, variable = "sea_water_temperature")
RNetCDF::att.get.nc(nc, variable = "sea_water_temperature", attribute = "units")

RNetCDF::var.get.nc(nc, variable = "sea_water_practical_salinity")
RNetCDF::att.get.nc(nc, variable = "sea_water_practical_salinity", attribute = "units")

RNetCDF::var.get.nc(nc, variable = "sea_water_salinity")
RNetCDF::att.get.nc(nc, variable = "sea_water_salinity", attribute = "units")

RNetCDF::var.get.nc(nc, variable = "sea_floor_temperature")
RNetCDF::att.get.nc(nc, variable = "sea_floor_temperature", attribute = "units")

RNetCDF::var.get.nc(nc, variable = "sea_floor_sound_speed_in_sea_water")
RNetCDF::att.get.nc(nc, variable = "sea_floor_sound_speed_in_sea_water", attribute = "units")

# Retrieve global attributes
RNetCDF::att.get.nc(nc, variable = "NC_GLOBAL", attribute = "cruise")
RNetCDF::att.get.nc(nc, variable = "NC_GLOBAL", attribute = "time_coverage_start")

RNetCDF::att.get.nc(nc, variable = "instrument", attribute = "calibration_date")
RNetCDF::att.get.nc(nc, variable = "instrument", attribute = "make_model")

RNetCDF::close.nc(nc)

# Opening with oce

library(oce)

ex_oce <- oce::read.netcdf("test_gapctd.nc")
ex_oce@data
ex_oce@metadata

# Opening with ncdf4

library(ncdf4)

nc <- ncdf4::nc_open(filename = "test_gapctd.nc")
print(nc)

ncdf4::ncvar_get(nc = nc, varid = "depth")
ncdf4::ncvar_get(nc = nc, varid = "index")

ncdf4::ncvar_get(nc, varid = "latitude")
ncdf4::ncvar_get(nc, varid = "longitude")
ncdf4::ncvar_get(nc, varid = "time")
ncdf4::ncvar_get(nc, varid = "sea_water_temperature")
ncdf4::ncatt_get(nc, varid = "sea_water_temperature", attname = "units")

ncdf4::ncvar_get(nc, varid = "sea_water_practical_salinity")
ncdf4::ncatt_get(nc, varid = "sea_water_practical_salinity", attname = "units")

ncdf4::ncvar_get(nc, varid = "sea_water_salinity")
ncdf4::ncatt_get(nc, varid = "sea_water_salinity", attname = "units")

ncdf4::ncvar_get(nc, varid = "sea_floor_temperature")
ncdf4::ncatt_get(nc, varid = "sea_floor_temperature", attname = "units")

ncdf4::ncvar_get(nc, varid = "sea_floor_sound_speed_in_sea_water")
ncdf4::ncatt_get(nc, varid = "sea_floor_sound_speed_in_sea_water", attname = "units")

# Retrieve global attributes
ncdf4::ncatt_get(nc, varid = 0, attname = "cruise")
ncdf4::ncatt_get(nc, varid = 0, attname = "time_coverage_start")

ncdf4::ncatt_get(nc, varid = "instrument", attname = "calibration_date")
ncdf4::ncatt_get(nc, varid = "instrument", attname = "make_model")

ncdf4::nc_close(nc)
